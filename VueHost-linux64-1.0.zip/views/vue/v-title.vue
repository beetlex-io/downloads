﻿<div>
    <h1 class="title">Vuejs host app</h1>
</div>
<style>
    .title {
        color:#ff6a00;
    }
</style>