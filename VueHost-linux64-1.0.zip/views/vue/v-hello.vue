﻿<div>
    <a href="javascript:void(0)" @click="onHello">Hello</a>
</div>
<script>
    {
        methods: {
            onHello(){
                alert('vuejs host!')
            }
        }
    }
</script>
<style>
    a {
        color:#ff0000;
    }
    a:hover{
        color:#808080;
    }
</style>